/*Vasu Sukhija
Michael Bradley
Sakith Agalawatte*/
import BarChart from './BarDisplay';
//import LineChart from './LineDisplay';
//bar chart
class showGraph{
    constructor(){
        
        this.fetchbarLineData();
    }

    fetchbarLineData() {
        fetch("./data.json")
            .then(data => data.json())
            .then(data => {
        this.barWidth = 1290;
        this.barHeight = 500;
        this.barPadding = 1;
        this.lineHeight = 400;
        this.lineWidth = 1200;
        this.barHolder = "#barSpace";
            
                this.graphData = data;
                console.log(data);
                
                let myBars = new BarChart(this.graphData, this.barHolder, this.barWidth, this.barHeight, this.barPadding, this.lineHeight, this.lineWidth);

            });
    };
}
// line chart

let graph = new showGraph();
//let myLines = new LineChart(lineHeight, lineWidth);










