import * as d3 from "d3";


export default class BarChart {
    constructor(barLineData, barHolder, barWidth, barHeight, padding, lnHeight, lnWidth) {
        this.w = barWidth;
        this.h = barHeight;
        this.h1 = lnHeight;
        this.w1 = lnWidth;
        this.padding = padding;
        this.barHolder = barHolder;
        this.barData = barLineData.graphData;


        //path of the line
        this.lineFun = d3.line()
            .x((d, i) => i * ((1163) / this.barData.length) + 90)
            .y(d => (400 - d.temp * 33.33) - 220)
            .curve(d3.curveLinear);

        this.buildChart();
    }

    buildChart() {
        // box height and width
        let svg = d3.select("#barSpace")
            .attr("width", this.w)
            .attr("height", this.h);

        // creating legend
        svg.append("circle").attr("cx", 100).attr("cy", 450).attr("r", 6).style("fill", "rgb(0,191,255)")
        svg.append("text").attr("x", 110).attr("y", 455).text("Negative Precipitation").style("font-size", "15px").style("font-family", "Arial")
        svg.append("circle").attr("cx", 300).attr("cy", 450).attr("r", 6).style("fill", "rgb(255, 0, 128)")
        svg.append("text").attr("x", 310).attr("y", 455).text("Positive Precipitation").style("font-size", "15px").style("font-family", "Arial")

        // label for the x axis
        svg.append("text")
            .attr("x", 665)
            .attr("y", 450)
            .style("font-size", "20px")
            .style("font-family", "Arial")
            .style("text-anchor", "middle")
            .text("Years (1970-2010)");

        // label for the precipitation y axis
        svg.append("text")
            .attr("x", 100)
            .attr("y", 30)
            .style("font-size", "20px")
            .style("font-family", "Arial")
            .style("text-anchor", "middle")
            .attr("transform", "translate(10,300) rotate(-90)")
            .text("Precipitation");

        // label for the temperature y axis
        svg.append("text")
            .attr("x", 100)
            .attr("y", 1270)
            .style("font-size", "20px")
            .style("font-family", "Arial")
            .style("text-anchor", "middle")
            .attr("transform", "translate(10,300) rotate(-90)")
            .text("Temperature");
        //bars height in th epositive and negative values
        svg.selectAll("rect")
            .data(this.barData)
            .enter()
            .append("rect")
            .attr("x", (d, i) => 89 + (i * 27.77))
            .attr("y", d => {
                if (d.precipitation < 0) {
                    return this.h - 320;
                } else {
                    return (this.h - (d.precipitation * 5 + 200) - 120);
                }
            })

            .attr("fill", d => { // colour filled in the bars according to the values
                if (d.precipitation < 0) {
                    return `rgb(0,191,255)`;
                } else {
                    return `rgb(255,0,128)`;
                }
            })
            .attr("width", 25) //width of the bars
            .attr("height", d => {
                if (d.precipitation < 0) {
                    return d.precipitation * (-1) * 5;
                } else {
                    return d.precipitation * 5;
                }
            });
        // texts used to display the values of the bars
        svg.selectAll("text")
            .data(this.barData)
            .enter()
            .append("text")
            .text(d => d.precipitation)
            .attr("x", (d, i) => 95 + (i * 27.77))
            .attr("y", d => {
                if (d.precipitation < 0) {
                    return this.h - 190 + d.precipitation * (-1) * 5 - 120;
                } else {
                    return (this.h - (d.precipitation * 5 + 210)) - 120;
                }
            })
            .attr("font-size", "15px")
            .attr("dy", "0.35em")
            .attr("fill", "rgb(0, 73, 73)")
            .attr("text-anchor", "start")

        //height and width of the scale
        var scale = d3.scaleLinear()
            .domain([40, -40])
            .range([0, 400]);

        // scale of the y-axis            
        var y_axis = d3.axisLeft()
            .scale(scale);


        svg.append("g")
            .attr("transform", "translate(89, -20)")
            .call(y_axis);

        // scale of the x-axis
        var scale2 = d3.scaleLinear()
            .domain([1970, 2010])
            .range([13, 1149]);

        var x_axis = d3.axisBottom().tickFormat(d3.format("d"))
            .scale(scale2);

        svg.append("g")
            .attr("transform", "translate(76, 380)")
            .call(x_axis);


        let viz = svg.append("path")
            .attr("d", this.lineFun(this.barData))
            .attr("stroke", "blue")
            .attr("fill", "none")
            .attr("stroke-width", 2)

        //labels of the graphs
        let labels = svg.selectAll("lineText")
            .data(this.barData)
            .enter()
            .append("text")
            .attr("class", "lineText")
            .text(d => d.temp)
            .attr("x", (d, i) => i * ((1170) / this.barData.length) + 80)
            .attr("y", d => (this.h1 - d.temp * 40) - 220)
            .attr("color", "red")
            .attr("font-size", "15px")
            .attr("dy", "0.20em")
            .attr("text-anchor", "start")


        //range and domain of y-axis    
        var yscale = d3.scaleLinear()
            .domain([6, -6])
            .range([0, 400]);

        // y axis scale          
        var y_axis = d3.axisRight()
            .scale(yscale);

        svg.append("g")
            .attr("transform", "translate(1225, -20)")
            .call(y_axis);

    }
}