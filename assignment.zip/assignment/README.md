# d3in_ES6_Classes
d3 with webpack, config, classes and auto cleaning
