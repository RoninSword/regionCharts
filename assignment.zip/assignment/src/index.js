/*Vasu Sukhija
Michael Bradley
Sakith Agalawatte*/
import BarChart from './BarDisplay';
//import LineChart from './LineDisplay';
//bar chart
let barWidth = 1350;
let barHeight = 500;
let barPadding = 1;
let barHolder = "#barSpace";
let lineHeight = 400;
let lineWidth = 1200;

let myBars = new BarChart(barHolder, barWidth, barHeight, barPadding, lineHeight, lineWidth);

// line chart


//let myLines = new LineChart(lineHeight, lineWidth);










