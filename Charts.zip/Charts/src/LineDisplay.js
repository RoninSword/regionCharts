import * as d3 from 'd3';

export default class LineChart {
    constructor(lnHeight, lnWidth) {
        this.h1 = lnHeight;
        this.w1 = lnWidth;
        //data of the chart
        this.graphData1 = [
            {"year":1970, "temp": -0.6, "precipitation": 3},

            {"year":1971, "temp": 0.3, "precipitation": 7},

            {"year":1972, "temp": -1.7, "precipitation": -20},

            {"year":1973, "temp": 1.4, "precipitation": 4},

            {"year":1974, "temp": -2.5, "precipitation": 18},

            {"year":1975, "temp": -0.3, "precipitation": 0},

            {"year":1976, "temp": -0.6, "precipitation": 12},

            {"year":1977, "temp": 2.4, "precipitation": -7},

            {"year":1978, "temp": -1.1, "precipitation": -2},

            {"year":1979, "temp": 0.9, "precipitation": 29},

            {"year":1980, "temp": 1.1, "precipitation": -7},

            {"year":1981, "temp": 1.3, "precipitation": 8},

            {"year":1982, "temp": -0.9, "precipitation": 6},

            {"year":1983, "temp": -0.2, "precipitation": 26},

            {"year":1984, "temp": 0.3, "precipitation": -7},

            {"year":1985, "temp": -0.3, "precipitation": 3},

            {"year":1986, "temp": 1.3, "precipitation": 2},

            {"year":1987, "temp": 2.6, "precipitation": -16},

            {"year":1988, "temp": 1.3, "precipitation": 8},

            {"year":1989, "temp": -0.8, "precipitation": -5},

            {"year":1990, "temp": -0.1, "precipitation": -14},

            {"year":1991, "temp": 1.1, "precipitation": 1},

            {"year":1992, "temp": -1.5, "precipitation": 7},

            {"year":1993, "temp": -0.1, "precipitation": -1},

            {"year":1994, "temp": -0.5, "precipitation": 2},

            {"year":1995, "temp": 0.1, "precipitation": -4},

            {"year":1996, "temp": -1.0, "precipitation": 0},

            {"year":1997, "temp": -1.8, "precipitation": 0},

            {"year":1998, "temp": 2.3, "precipitation": -3},

            {"year":1999, "temp": 3.3, "precipitation": 6},

            {"year":2000, "temp": 1.7, "precipitation": 7},

            {"year":2001, "temp": 2.5, "precipitation": -2},

            {"year":2002, "temp": -1.8, "precipitation": 15},

            {"year":2003, "temp": -0.8, "precipitation": -21},

            {"year":2004, "temp": -0.5, "precipitation": 14},

            {"year":2005, "temp": 1.5, "precipitation": -6},

            {"year":2006, "temp": 3.7, "precipitation": 3},

            {"year":2007, "temp": 0.4, "precipitation": 9},

            {"year":2008, "temp": -0.2, "precipitation": 14},

            {"year":2009, "temp": -0.4, "precipitation": 18},

            {"year":2010, "temp": 4.2, "precipitation": -14}
        ];
        //path of the line
        this.lineFun = d3.line()
            .x((d, i) => i * ((1170) / this.graphData1.length)+30)
            .y(d => (400 - d.temp*40)-155)
            .curve(d3.curveLinear); 

        this.buildLineChart();
    }

    buildLineChart() {
        
        let svg = d3.select("#lineSpace")
            .attr("width", this.w1)
            .attr("height", this.h1);
            
        let viz = svg.append("path")
            .attr("d", this.lineFun(this.graphData1))
            .attr("stroke", "blue")
            .attr("fill", "none")
            .attr("stroke-width",3)
            
            //labels of the graphs
        let labels = svg.selectAll("text")
            .data(this.graphData1)
            .enter()
            .append("text")
            .text(d => d.temp)
            .attr("x", (d, i) => i * ((1170) / this.graphData1.length)+25)
            .attr("y",d => this.h1 - d.temp*45-160)
            .attr("font-size", "15px")
            .attr("dy", "0.20em")
            .attr("text-anchor", "start")
            
            //range and domain of x-axis 
            var xscale = d3.scaleLinear()
            .domain([1970, 2010])
            .range([13, 1156]);
            // x axis scale
            var x_axis = d3.axisBottom()
            .scale(xscale);

            svg.append("g")
            .attr("transform", "translate(15, 245.5)")
            .call(x_axis);

            //range and domain of y-axis 
            var yscale = d3.scaleLinear()
                        .domain([6, -3])
                        .range([0, 400]);
        
             // y axis scale          
            var y_axis = d3.axisLeft()
                        .scale(yscale);

            svg.append("g")
            .attr("transform", "translate(29, -20)")
            .call(y_axis);
        
    }
}